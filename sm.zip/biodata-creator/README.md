# Biodata Creator

A small, self-contained vanilla JS app for putting together a biodata:
pick a template, fill in your details, add or delete whatever fields you
need, and download the result as a PDF.

## Running it

No build step and no server required — just open `index.html` in a
modern browser (Chrome, Edge, Firefox, Safari).

- **Works fully offline.** The PDF export library is bundled in
  `js/vendor/`, so it works without an internet connection. The two
  Google Fonts used for headings load from the internet on first open;
  if there's no connection, the page just falls back to your system
  font — nothing breaks.
- **Your data never leaves your device.** There's no backend — details
  and your uploaded photo are kept only in this browser's local storage
  on this machine, so the page remembers your work if you close and
  reopen it. Use "Reset everything" to clear it.

## Folder structure

```
biodata-creator/
├── index.html          Page structure
├── css/
│   └── style.css        All styling, including the 4 templates
├── js/
│   ├── templates.js      Template list + template-picker rendering
│   ├── pdf-export.js     PDF export (html2pdf.js) and print fallback
│   ├── app.js             State, rendering, and all editing behaviour
│   └── vendor/
│       └── html2pdf.bundle.min.js   Bundled PDF library (MIT licensed)
├── assets/
│   └── ganesha.svg        Standalone copy of the emblem artwork for
│                           reference (the app itself uses a copy
│                           inlined in js/app.js — see note below)
└── README.md
```

## Using the app

1. **Choose a template** — Traditional, Modern, Royal, or Blush. You can
   switch anytime; your details carry over.
2. **Add a photo** (optional) — shown in the top-right corner of the sheet.
3. **Fill in your details** — organised into sections (Personal, Education
   & Career, Family, Contact, Additional Information).
   - Click into any label or value to edit it.
   - **+ Add field** adds a new row to a section.
   - **✕** next to a field deletes just that field; **✕** next to a
     section title deletes the whole section.
   - **+ Add a section** creates a new custom section.
   - Blank fields are automatically hidden from the preview and the PDF,
     so you don't have to delete fields you simply haven't filled in yet.
4. **Download PDF** generates a PDF of exactly what's shown in the
   preview. **Print** opens your browser's print dialog as a
   no-dependency alternative (choose "Save as PDF" as the destination).

## Customising further

- To change the default fields people start with, edit `defaultState()`
  in `js/app.js`.
- To add a 5th template, add an entry to the `TEMPLATES` array in
  `js/templates.js` and a matching `.template-yourid { ... }` block in
  `css/style.css` (copy one of the existing template blocks as a
  starting point — each one only needs to set a handful of CSS
  variables).
- The Ganesha artwork is defined twice on purpose: once as the
  standalone `assets/ganesha.svg` (handy if you want to reuse it
  elsewhere), and once as the `GANESHA_EMBLEM_SVG` constant near the
  top of `js/app.js`, which is what actually gets drawn into the
  preview. It's inlined there — rather than loaded as an `<img>` —
  so the PDF export always has direct access to it with no separate
  file request involved. If you swap the artwork, update both copies.

## Troubleshooting

**PDF downloads but looks blank or cut off.** This was an issue in an
earlier version of this app: exporting while the page was scrolled
down (very easy to do on a phone, since you scroll to reach the
Download button) could capture the wrong area. It's fixed now — export
resets the scroll position and a temporary display-only scaling effect
before capturing, then puts both back afterwards. If you still see a
blank PDF, check the browser's console for errors and make sure
`js/vendor/html2pdf.bundle.min.js` was included when you copied/shared
the folder — it's a ~1MB file some tools skip by mistake.

**Layout looks cramped or text wraps oddly on a small screen.** The
sheet is designed at a fixed print width (like a real page) and is
scaled down to fit your screen automatically. If you've edited the CSS
and this stops working, check that `.biodata-sheet` still has a fixed
`width` and no `max-width`, since that combination is what lets
`js/app.js`'s `fitPreviewToContainer()` compute the right scale.
